<html>
 <head>
  <title>Super Admin - Main</title>

		<link rel="stylesheet" type="text/css" href="style.css" />
	
 </head>
 <body>
	<h2>College Event Website</h2>
	<p><h3>Welcome SuperAdmin!</h3></p>
	
	<h3>Please narrow your search</h3>
	
	~Dropdown items populated by database, need php</p>
	<p>Select State: 
	<select>
		<option value="Public">Florida</option>
		<option value="Private">Georgia</option>
		<option value="RSO">Alabama</option>
	</select>
	Select City
	<select> <!--will be options from database-->
		<option value="Public">Orlando</option>
		<option value="Private">Miama</option>
		<option value="RSO">Atlanta</option>
	</select>
	
	
	
	<p>
	<a href="superadminlist.php" class="button">Browse Locations</a>
	
	
	<a href="superadminadd.php" class="button">Add a Location</a>
	
 </body>
</html>